package com.naruto.project.naruto.api.repositories.Missoes;

public class NinjaComum extends Ninja {

    private int numeroMissoes = 0; //Número de missões que o ninja já fez
       //private Double valorMissao; // calcula valor da missão de acordo comm o nivel

    //construtor


    public NinjaComum(String nome, String cla, String especialidade, Double salarioBase, int numeroMissoes) {
        super(nome, cla, especialidade, salarioBase);
        this.numeroMissoes = numeroMissoes;
    }

    public void setNumeroMissoes(int numeroMissoes) {
        this.numeroMissoes = numeroMissoes;
    }

    public int getNumeroMissoes() {
        return numeroMissoes;
    }

    // toString
    @Override
    public String toString() {
        return
                " \n Numero de Missoes realizadas " + numeroMissoes +
                super.toString();
    }

    //        for (String nivel:nivelAlto) {
//            if(rank.equals(nivel)){
//                valorUltimaMissao = Double.valueOf(salarioBase * 50);
//            }else {
//                for (String nivel2 : nivelMedio) {
//                    if (rank.equals(nivel2)) {
//                        valorUltimaMissao =salarioBase * 30;
//                    } else if (rank.equals("d")) {
//                        valorUltimaMissao =salarioBase * 20;
//                    } else {
//                        throw new Exception("Nivel inválido");
//                    }
//
//                }
//            }
//        }


}





