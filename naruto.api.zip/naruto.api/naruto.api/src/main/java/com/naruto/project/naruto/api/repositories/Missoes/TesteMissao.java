package com.naruto.project.naruto.api.repositories.Missoes;
import java.util.Scanner;

public class TesteMissao {

    public static void main(String[] args) {


        Scanner leitor = new Scanner(System.in);
        Scanner leitor2 = new Scanner(System.in);
        Boolean continuar = true;

        com.naruto.project.naruto.api.repositories.Missoes.Kage hokage = new com.naruto.project.naruto.api.repositories.Missoes.Kage("Hashirama", "Senju", "Genjutso", 10000.0, "Konorra", 1);
        System.out.println(hokage);

        do {
            System.out.println("Qual nivel de missão você deseja? \n" +
                    "RANK MISSÕES: S A B C D, sendo D mais baixo e S mais alto " +
                    "Obs: Apenas letras maiusculas para sair digite 'SAIR'");

            String missaoDesejada = leitor.nextLine();
            switch (missaoDesejada) {

                case "S":
                    com.naruto.project.naruto.api.repositories.Missoes.Missao missao5 = new com.naruto.project.naruto.api.repositories.Missoes.Missao("Missão para Sannins", missaoDesejada, 10000.0);
                    com.naruto.project.naruto.api.repositories.Missoes.NinjaComum ninjas = new com.naruto.project.naruto.api.repositories.Missoes.NinjaComum("Jiraya", "Senju", "Invocar sapos", 500.0, 205);
                    com.naruto.project.naruto.api.repositories.Missoes.NinjaComum ninjas2 = new com.naruto.project.naruto.api.repositories.Missoes.NinjaComum("Tsunade", "Senju", "Invocar lesmas", 500.0, 203);
                    missao5.addNinja(ninjas);
                    missao5.addNinja(ninjas2);
                    missao5.exibeTime();
                    System.out.println(missao5 + "Essa missão terá o valor de " + missao5.valorTotalMissao());
                    break;
                case "A":
                    com.naruto.project.naruto.api.repositories.Missoes.Missao missao4 = new com.naruto.project.naruto.api.repositories.Missoes.Missao("Missão para Ambu", missaoDesejada, 6000.0);
                    com.naruto.project.naruto.api.repositories.Missoes.NinjaComum ninjas3 = new com.naruto.project.naruto.api.repositories.Missoes.NinjaComum("Kakashi", "Hatake", "Chidori", 150.0, 180);
                    com.naruto.project.naruto.api.repositories.Missoes.NinjaComum ninjas4 = new com.naruto.project.naruto.api.repositories.Missoes.NinjaComum("Obito", "Uchiha", "Sharingan", 150.0, 180);
                    missao4.addNinja(ninjas3);
                    missao4.addNinja(ninjas4);
                    missao4.exibeTime();
                    System.out.println("Essa missão terá o valor de " + missao4.valorTotalMissao());
                    break;
                case "B":
                    com.naruto.project.naruto.api.repositories.Missoes.Missao missao3 = new com.naruto.project.naruto.api.repositories.Missoes.Missao("Missão para Junnin", missaoDesejada, 4000.0);
                    com.naruto.project.naruto.api.repositories.Missoes.NinjaComum ninjas5 = new com.naruto.project.naruto.api.repositories.Missoes.NinjaComum("Gai", "Maito", "Taijutso", 149.0, 156);
                    com.naruto.project.naruto.api.repositories.Missoes.NinjaComum ninjas6 = new com.naruto.project.naruto.api.repositories.Missoes.NinjaComum("Neji", "Hyuuga", "Byakugan", 135.0, 151);
                    missao3.addNinja(ninjas5);
                    missao3.addNinja(ninjas6);
                    missao3.exibeTime();
                    System.out.println("Essa missão terá o valor de " + missao3.valorTotalMissao());
                    break;
                case "C":
                    com.naruto.project.naruto.api.repositories.Missoes.Missao missao2 = new com.naruto.project.naruto.api.repositories.Missoes.Missao("Missão para Chunnin", missaoDesejada, 3000.0);
                    com.naruto.project.naruto.api.repositories.Missoes.NinjaComum ninjas7 = new com.naruto.project.naruto.api.repositories.Missoes.NinjaComum("Shino", "Aburame", "Dominar incetos", 100.0, 100);
                    com.naruto.project.naruto.api.repositories.Missoes.NinjaComum ninjas8 = new com.naruto.project.naruto.api.repositories.Missoes.NinjaComum("Kiba", "Inuzuka", "Rastreador", 100.0, 100);
                    missao2.addNinja(ninjas7);
                    missao2.addNinja(ninjas8);
                    missao2.exibeTime();
                    System.out.println("Essa missão terá o valor de " + missao2.valorTotalMissao());
                    break;
                case "D":
                    com.naruto.project.naruto.api.repositories.Missoes.Missao missao = new com.naruto.project.naruto.api.repositories.Missoes.Missao("Missão para Gennins", missaoDesejada, 2000.0);
                    com.naruto.project.naruto.api.repositories.Missoes.NinjaComum ninjas9 = new com.naruto.project.naruto.api.repositories.Missoes.NinjaComum("Sakura", "Haruno", "Kunoichi", 500.0, 80);
                    com.naruto.project.naruto.api.repositories.Missoes.NinjaComum ninjas10 = new com.naruto.project.naruto.api.repositories.Missoes.NinjaComum("Naruto", "Uzumaki", "Clone das Sombras", 500.0, 80);
                    missao.addNinja(ninjas9);
                    missao.addNinja(ninjas10);
                    missao.exibeTime();
                    System.out.println("Essa missão terá o valor de " + missao.valorTotalMissao());
                    break;
                case "SAIR":
                    continuar = false;
                    break;
                default:
                    System.out.println("Opção invalida");
                    break;

            }
        } while (continuar);
    }
}



//             String[] nivelAlto = {"s","a"};
//            String[] nivelMedio = {"b", "c"};
//
//
//            if(nivelAlto.equals(rank)){
//                valorMissao = Double.valueOf(salarioBase * 50);
//            } else if(nivelMedio.equals(rank)){
//                valorMissao =salarioBase * 30;
//            } else if (rank.equals("d")) {
//                valorMissao = salarioBase * 20;
//            } else{
//                throw new Exception("Nivel inválido");
//            }
//
//        }



        //atribuir ninja ninha
        //atriinir ninja 2
        //atribuir ninja 3
        //atribir
        //essa missão é x valor




