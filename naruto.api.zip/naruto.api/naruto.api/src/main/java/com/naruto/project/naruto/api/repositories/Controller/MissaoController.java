package com.naruto.project.naruto.api.repositories.Controller;

import com.naruto.project.naruto.api.repositories.Missoes.NinjaComum;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@RestController
@RequestMapping("/missoes")

public class MissaoController {

    private String nome;

    private List<NinjaComum> ninjas;

    public MissaoController() {
        this.ninjas = new ArrayList<>();
    }

    @GetMapping("/listar")
    public ResponseEntity getNinjas() {
        return ResponseEntity.ok(ninjas);
    }

    @PostMapping("/cadastrar")
    public ResponseEntity cadastrarNinja(@RequestBody NinjaComum novoNinja) {
        ninjas.add(novoNinja);//adiciona ninja a missões
        return ResponseEntity.created(null).build();
    }

    @PostMapping("/cadastrar/nome")
    public ResponseEntity cadastrarNom(@RequestBody String nomeNovoNinja) {
        this.nome = nomeNovoNinja;
        return (ResponseEntity) ResponseEntity.created(null);
    }

    @GetMapping("/nomes")
    public ResponseEntity nomesNinjas() {
        return ResponseEntity.ok(this.nome);
    }



}