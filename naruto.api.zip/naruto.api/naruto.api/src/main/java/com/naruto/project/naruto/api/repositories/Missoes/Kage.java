package com.naruto.project.naruto.api.repositories.Missoes;

public class Kage extends Ninja { // é o nivel mais alto dos ninjas, tipo um presidente

    private String vilaQueLidera; // qual vila ele lidera (é presidente)
    private Integer ordinal; //Qual a ordem desse kage se é primeiro, segundo, terceiro e asssim por diante

    //contrutor

    public Kage(String nome, String cla, String especialidade, Double salarioBase, String vilaQueLidera, Integer ordinal) {
        super(nome, cla, especialidade, salarioBase);
        this.vilaQueLidera = vilaQueLidera;
        this.ordinal = ordinal;
    }

    @Override
    public String toString() {
        return  " \n Vila Que Lidera " + vilaQueLidera +
                " \n Sucessão ordinal " + ordinal +
                 super.toString() + "\n";
    }
}
