package com.naruto.project.naruto.api.repositories.Missoes;

public abstract class  Ninja { //classe abstrata de ninja

    private String nome; //nome do ninja
    private String cla; // clã pertencente ou familia
    private String especialidade; // se é ninja médico ou estragegista por exemplo
    private Double salarioBase; //salario base para caluco de missões

//construtor
    public Ninja(String nome, String cla, String especialidade, Double salarioBase) {
        this.nome = nome;
        this.cla = cla;
        this.especialidade = especialidade;
        this.salarioBase = salarioBase;
    }


//getters

    public String getNome() {
        return nome;
    }

    public String getCla() {
        return cla;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public Double getSalarioBase() {
        return salarioBase;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCla(String cla) {
        this.cla = cla;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public void setSalarioBase(Double salarioBase) {
        this.salarioBase = salarioBase;
    }

    //to string
    @Override
    public String toString() {
        return
                "\n Nome " + nome +
                "\n Clã " + cla +
                "\n Especialidade " + especialidade +
                "\n Salário Base: " + salarioBase;

    }
}
