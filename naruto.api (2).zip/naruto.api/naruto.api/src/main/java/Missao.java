import java.util.ArrayList;
import java.util.List;

public class Missao {
    private String descricao; // descrição breve da misssão
    private String rank; //qual a dificuldade da missão
    private Double valor; //preço da missão
    private List<Ninja> lista;

    public Missao(String descricao, String rank, Double valor) {
        this.descricao = descricao;
        this.rank = rank;
        this.valor = valor;
        lista = new ArrayList<>();
    }

    public void addNinja(Ninja n){
        lista.add(n);
    }

    public void exibeTime(){
        System.out.println(lista);
        for (Ninja n : lista){
            System.out.println("Time designado para missão" + n);
        }
    }

public Double valorTotalMissao(){
        Double total = 0.0;
        for (Ninja n: lista){
            total += n.getSalarioBase();
        }
        return total;

}

    @Override
    public String toString() {
        return " \n Missao: " +
                " \n Descrição: " + descricao +
                " \n Rank: " + rank +
                " \n Valor: " + valor +
                " \n Lista: " + lista ;
    }
}
