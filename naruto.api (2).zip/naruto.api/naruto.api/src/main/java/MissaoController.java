import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@RestController
@RequestMapping("/missoes")
public class MissaoController {

private List<NinjaComum> ninjas = new ArrayList<>();


@GetMapping("listar/ninjas")
    public List<NinjaComum> getNinjas(){
    return ninjas;
}

@PostMapping("adicionar/ninja")
    public void cadastrarNinja(@RequestBody NinjaComum novoNinja){
    ninjas.add(novoNinja);//adiciona ninja a missões
}

}
