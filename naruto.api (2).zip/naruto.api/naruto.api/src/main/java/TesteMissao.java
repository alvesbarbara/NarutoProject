import java.util.Scanner;

public class TesteMissao {
    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);
        Scanner leitor2 = new Scanner(System.in);
        Boolean continuar = true;

        Kage hokage = new Kage("Hashirama", "Senju", "Genjutso", 10000.0, "Konorra", 1 );
        System.out.println(hokage);

        do{
        System.out.println("Qual nivel de missão você deseja? \n" +
                "RANK MISSÕES: S A B C D, sendo D mais baixo e S mais alto " +
                "Obs: Apenas letras maiusculas para sair digite 'SAIR'");

        String missaoDesejada = leitor.nextLine();
        switch (missaoDesejada) {

            case "S":
                Missao missao5 = new Missao("Missão para Sannins", missaoDesejada, 100.0);
                NinjaComum ninjas = new NinjaComum("Jiraya", "Senju", "Invocar sapos", 100, 200.0);
                NinjaComum ninjas2 = new NinjaComum("Tsunade", "Senju", "Invocar lesmas", 500, 200.0);
                missao5.addNinja(ninjas);
                missao5.addNinja(ninjas2);
                missao5.exibeTime();
                System.out.println(missao5 + "Essa missão terá o valor de " + missao5.valorTotalMissao());
                break;
            case "A":
                Missao missao4 = new Missao("Missão para Ambu", missaoDesejada, 50.0);
                NinjaComum ninjas3 = new NinjaComum("Kakashi", "Hatake", "Chidori", 150, 180.0);
                NinjaComum ninjas4 = new NinjaComum("Obito", "Uchiha", "Sharingan", 150, 180.0);
                missao4.addNinja(ninjas3);
                missao4.addNinja(ninjas4);
                missao4.exibeTime();
                System.out.println("Essa missão terá o valor de " + missao4.valorTotalMissao());
                break;
            case "B":
                Missao missao3 = new Missao("Missão para Junnin", missaoDesejada, 40.0);
                NinjaComum ninjas5 = new NinjaComum("Gai", "Maito", "Taijutso", 149, 150.0);
                NinjaComum ninjas6 = new NinjaComum("Neji", "Hyuuga", "Byakugan", 135, 150.0);
                missao3.addNinja(ninjas5);
                missao3.addNinja(ninjas6);
                missao3.exibeTime();
                System.out.println("Essa missão terá o valor de " + missao3.valorTotalMissao());
                break;
            case "C":
                Missao missao2 = new Missao("Missão para Chunnin", missaoDesejada, 30.0);
                NinjaComum ninjas7 = new NinjaComum("Shino", "Aburame", "Dominar incetos", 100, 100.0);
                NinjaComum ninjas8 = new NinjaComum("Kiba", "Inuzuka", "Rastreador", 101, 100.0);
                missao2.addNinja(ninjas7);
                missao2.addNinja(ninjas8);
                missao2.exibeTime();
                System.out.println("Essa missão terá o valor de " + missao2.valorTotalMissao());
                break;
            case "D":
                Missao missao = new Missao("Missão para Gennins", missaoDesejada, 20.0);
                NinjaComum ninjas9 = new NinjaComum("Sakura", "Haruno", "Kunoichi", 50, 80.0);
                NinjaComum ninjas10 = new NinjaComum("Naruto", "Uzumaki", "Clone das Sombras", 66, 80.0);
                missao.addNinja(ninjas9);
                missao.addNinja(ninjas10);
                missao.exibeTime();
                System.out.println("Essa missão terá o valor de " + missao.valorTotalMissao());
                break;
            case "SAIR":
                continuar = false;
                break;
                default:
                System.out.println("Opção invalida");
                break;

        }
        }while (continuar);





//             String[] nivelAlto = {"s","a"};
//            String[] nivelMedio = {"b", "c"};
//
//
//            if(nivelAlto.equals(rank)){
//                valorMissao = Double.valueOf(salarioBase * 50);
//            } else if(nivelMedio.equals(rank)){
//                valorMissao =salarioBase * 30;
//            } else if (rank.equals("d")) {
//                valorMissao = salarioBase * 20;
//            } else{
//                throw new Exception("Nivel inválido");
//            }
//
//        }



        //atribuir ninja ninha
        //atriinir ninja 2
        //atribuir ninja 3
        //atribir
        //essa missão é x valor

    }
}
