public class Hokage extends Ninja{

    public Hokage(String nome, String vila, Double forca, Integer nivel) {
        super(nome, vila, forca, nivel);
    }

    public void calculaMissao(){

    } //nesse método o Hokage irá determinar para qual missão irá ára qual time ou ninja
}
