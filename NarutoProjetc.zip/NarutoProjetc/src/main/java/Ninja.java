public abstract class Ninja {
    private String nome, vila;
    private Double forca;
    private Integer nivel;



    public Ninja(String nome, String vila, Double forca, Integer nivel) {
        this.nome = nome;
        this.vila = vila;
        this.forca = forca;
        this.nivel = nivel;

    }

    public String getNome() {
        return nome;
    }

    public String getVila() {
        return vila;
    }

    public Double getForca() {
        return forca;
    }

    public Integer getNivel() {
        return nivel;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setVila(String vila) {
        this.vila = vila;
    }

    public void setForca(Double forca) {
        this.forca = forca;
    }

    public void setNivel(Integer nivel) {
        this.nivel = nivel;
    }

    @Override
    public String toString() {
        return "Ninja do Shinobi" + nome +
                "Vila de origem: " + vila +
                "Chakra" + forca + "\n";
    }
}
